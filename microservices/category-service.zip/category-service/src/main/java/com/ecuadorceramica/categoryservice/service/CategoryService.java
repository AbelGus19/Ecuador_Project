package com.ecuadorceramica.categoryservice.service;

import com.ecuadorceramica.categoryservice.dto.RequestCategoryDTO;
import com.ecuadorceramica.categoryservice.dto.ResponseCategoryDTO;
import java.util.List;

public interface CategoryService {
    ResponseCategoryDTO createCategory(RequestCategoryDTO categoryDTO);
    ResponseCategoryDTO getCategoryById(String id);
    List<ResponseCategoryDTO> getAllCategories();
    ResponseCategoryDTO updateCategory(String id, RequestCategoryDTO categoryDTO);
    void deleteCategory(String id);
}