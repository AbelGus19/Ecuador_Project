package com.ecuadorceramica.categoryservice.controller;

import com.ecuadorceramica.categoryservice.dto.RequestCategoryDTO;
import com.ecuadorceramica.categoryservice.dto.ResponseCategoryDTO;
import com.ecuadorceramica.categoryservice.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/categories")
@RequiredArgsConstructor
@Tag(name = "Category API", description = "API para gestión de categorías de productos")
public class CategoryController {
    
    private final CategoryService categoryService;
    
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear una nueva categoría")
    public ResponseCategoryDTO createCategory(@Valid @RequestBody RequestCategoryDTO categoryDTO) {
        return categoryService.createCategory(categoryDTO);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Obtener categoría por ID")
    public ResponseCategoryDTO getCategoryById(@PathVariable String id) {
        return categoryService.getCategoryById(id);
    }
    
    @GetMapping
    @Operation(summary = "Listar todas las categorías")
    public List<ResponseCategoryDTO> getAllCategories() {
        return categoryService.getAllCategories();
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Actualizar categoría existente")
    public ResponseCategoryDTO updateCategory(
            @PathVariable String id, 
            @Valid @RequestBody RequestCategoryDTO categoryDTO) {
        return categoryService.updateCategory(id, categoryDTO);
    }
    
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar categoría")
    public void deleteCategory(@PathVariable String id) {
        categoryService.deleteCategory(id);
    }
}