package com.ecuadorceramica.categoryservice.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ResponseCategoryDTO {
    private String id;
    private String name;
    private String description;
    private LocalDateTime createdAt;
}