package com.ecuadorceramica.categoryservice.service;

import com.ecuadorceramica.categoryservice.dto.RequestCategoryDTO;
import com.ecuadorceramica.categoryservice.dto.ResponseCategoryDTO;
import com.ecuadorceramica.categoryservice.model.Category;
import com.ecuadorceramica.categoryservice.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {
    
    private final CategoryRepository categoryRepository;
    private final ModelMapper modelMapper;
    
    @Override
    public ResponseCategoryDTO createCategory(RequestCategoryDTO categoryDTO) {
        Category category = modelMapper.map(categoryDTO, Category.class);
        category.setCreatedAt(LocalDateTime.now());
        Category savedCategory = categoryRepository.save(category);
        return modelMapper.map(savedCategory, ResponseCategoryDTO.class);
    }
    
    @Override
    public ResponseCategoryDTO getCategoryById(String id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
        return modelMapper.map(category, ResponseCategoryDTO.class);
    }
    
    @Override
    public List<ResponseCategoryDTO> getAllCategories() {
        return categoryRepository.findAll().stream()
                .map(category -> modelMapper.map(category, ResponseCategoryDTO.class))
                .collect(Collectors.toList());
    }
    
    @Override
    public ResponseCategoryDTO updateCategory(String id, RequestCategoryDTO categoryDTO) {
        Category existingCategory = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
        
        modelMapper.map(categoryDTO, existingCategory);
        Category updatedCategory = categoryRepository.save(existingCategory);
        return modelMapper.map(updatedCategory, ResponseCategoryDTO.class);
    }
    
    @Override
    public void deleteCategory(String id) {
        categoryRepository.deleteById(id);
    }
}