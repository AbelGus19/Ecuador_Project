# Category Service - Ecuador Cerámico

Microservicio para la gestión de categorías de productos artesanales.

## Requisitos
- Java 17
- Maven 3.8+
- Docker (opcional)
- MongoDB

## Ejecución local

1. Clonar el repositorio
2. Configurar las variables de entorno en `src/main/resources/.env`: